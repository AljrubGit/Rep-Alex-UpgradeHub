# Ejercicio Selectores CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/AleRubioF/pen/mdjGwLo](https://codepen.io/AleRubioF/pen/mdjGwLo).

