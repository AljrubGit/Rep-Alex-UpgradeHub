# Ejercicio 2 → Creando bloques separados

A Pen created on CodePen.io. Original URL: [https://codepen.io/AleRubioF/pen/NWBBYdP](https://codepen.io/AleRubioF/pen/NWBBYdP).

