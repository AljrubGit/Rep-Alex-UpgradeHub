# Etiquetas semánticas y de contenido

A Pen created on CodePen.io. Original URL: [https://codepen.io/AleRubioF/pen/eYjKMve](https://codepen.io/AleRubioF/pen/eYjKMve).

