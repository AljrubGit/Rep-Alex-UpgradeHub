# Estructura básica de un HTML

A Pen created on CodePen.io. Original URL: [https://codepen.io/upgradehub/pen/LYZBMMQ](https://codepen.io/upgradehub/pen/LYZBMMQ).

