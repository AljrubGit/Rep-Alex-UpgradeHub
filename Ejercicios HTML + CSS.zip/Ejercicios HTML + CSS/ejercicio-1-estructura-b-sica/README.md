# Ejercicio 1 → Estructura básica

A Pen created on CodePen.io. Original URL: [https://codepen.io/AleRubioF/pen/rNrrdBW](https://codepen.io/AleRubioF/pen/rNrrdBW).

