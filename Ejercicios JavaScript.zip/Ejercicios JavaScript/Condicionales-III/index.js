// Estamos en un juicio y esperamos la sentencia del Juez para ello tendremos que declarar una variable culpable con el valor 'si', 'no' u 'otro'- y otra variable sentencia asignando un string vacío

// Si culpable es = 'si' -> sentencia será 'a la carcel'
// Si culpable es = 'no' -> sentencia será 'vas a casa'
// En caso de no ser 'si' o 'no' -> sentencia será 'realizar trabajos para la comunidad'


var culpable = true || false || "other";
var sentencia = "";

if (culpable = true) {
   culpable = "si";
  } else if (culpable = false) {
   culpable = "no";

if (culpable = "si") {
  sentencia = "a la carcel";
  } else if (culpable = "no"); 
  sentencia = "vas a casa"; 
  } else if (culpable = "other") ;
  sentencia = "realizar trabajos comunitarios";
  

  