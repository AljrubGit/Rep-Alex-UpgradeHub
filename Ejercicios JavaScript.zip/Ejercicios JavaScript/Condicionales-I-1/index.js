// Crea una variable llamada 'age' y asignale el valor 17 (número)


// Crea una variable llamada 'isUsa' y asignale el valor booleano true


// Crea una variable llamada 'youCanDrive' y asignale el valor booleano false


// Crea una condición que nos diga si una persona con 17 años puede conducir ->
// Tendrás que asignar el valor true a 'youCanDrive' si la variable 'age' es mayor a 18 años, pero si está en USA y es mayor de 16 años también asigna el valor true a 'youCanDrive'.

var age = 17;
var isUsa = true
var youCanDrive = false

if (age < 18) {
  console.log("No puedes conducir.")
  }

if (age > 18 || (age >= 16 && isUsa)) {
  youCanDrive = true;
  }