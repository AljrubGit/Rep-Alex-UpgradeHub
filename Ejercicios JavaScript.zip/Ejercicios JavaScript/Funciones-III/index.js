// Dada una variable superheroes que sea un array con algunos heroes dentro.
var superheroes = ['Spiderman', 'Hulk']

// Crea ahora una función empujarHeroe que reciba un argumento arrayHeroes (será un array) y otro argumento nuevoHeroe (será un string) y empuje dentro de arrayHeroes el argumento nuevoHeroe.


// Invoca a la función empujarHeroe enviando el array superheroes y el string "Thor".



// Invoca a la función empujarHeroe enviando el array superheroes y el string "Iron-Man".


// Crea ahora una función sacarHeroe que reciba un argumento arrayHeroes (será un array) y saque de este array el último elemento (¡recuerda la sección de arrays del prework!).


// Invoca a la función sacarHeroe enviando el array superheroes

function empujarHeroe(arrayHeroes, nuevoHeroe){
  console.log(arrayHeroes.push(nuevoHeroe))
}
var arrayHeroes = empujarHeroe("Thor") 
console.log(empujarHeroe)

function empujarHeroe(superheroes, nuevoHeroe){
  console.log(superheroes.push(nuevoHeroe))
}
var arrayHeroes = empujarHeroe("Iron-Man") 
console.log(empujarheroe)

function sacarHeroe (arrayHeroes){
  console.log(arrayHeroes.pop())
}



