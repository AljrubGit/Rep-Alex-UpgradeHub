// Crea una variable llamada numeros que sea un array vacío


// Crea un bucle for que recorra los números empezando en 0 y llegando hasta 10 (INCLUYENDO EL 10). En cada iteración, empuja ese número i dentro del array numeros


// Para terminar, vamos a quitar los dos últimos números del array.
var numeros = []

for (i=0;i<10;i++){
    numeros.push(i)
  }
numeros.pop([2]);
