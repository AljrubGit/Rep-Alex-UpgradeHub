// Crea una variable sumaTotal que empiece valiendo 0.


// Ahora, crea un bucle for que recorra los números desde 0 hasta 20 (SIN INCLUIR EL 20) y sume todos los números a sumaTotal.

var sumaTotal = 0; 

for (var i = 0; i < 20; i++) {
  sumaTotal += i;
  }

console.log(sumaTotal);