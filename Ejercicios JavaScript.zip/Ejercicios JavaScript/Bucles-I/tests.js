// ¡NO TOCAR ESTE ARCHIVO! MODIFICARLO HARÁ QUE LOS RESULTADOS SEAN ERRÓNEOS Y EL EJERCICIO NO ESTÉ CORRECTAMENTE RESUELTO

// Set up mocha
mocha.setup('bdd');

// Establish variables for use in all tests
const { assert, expect } = chai;

describe('Test - Bucles I', () => {
  it('La variable sumaTotal debe estar definida', () => {
    expect(sumaTotal).to.not.be.an('undefined');
  });

  it('La variable sumaTotal valdrá 190', () => {
    expect(sumaTotal).to.equal(190);
  });
});
