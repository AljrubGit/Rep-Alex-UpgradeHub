// Declara dos variables numeroA y numeroB con los valores 5 y 7 respectivamente.


// Declara una variable sumaTotal que sea igual a la suma de numeroA y numeroB


// Declara una variable restaTotal que sea igual a la resta de numeroB menos numeroA


// Declara una variable multiTotal que sea igual a la multiplicación de sumaTotal por restaTotal


// Declara una variable divisionTotal que sea igual a la división de multiTotal entre restaTotal

var numeroA = 5;
var numeroB = 7;

var sumaTotal = numeroA + numeroB;

var restaTotal = numeroB - numeroA;

var multiTotal = sumaTotal * restaTotal;

var divisionTotal = multiTotal / restaTotal;