// Declara dos variables name y surname que representen el nombre y apellidos de una persona. No les asignes ningún valor, es decir, deben ser variables NO inicializadas.


// Cambia el valor de la variable name para que sea 'Upgrade'


// Cambia el valor de la variable surname para que sea 'Hub''

var name;
var surname; 

name = "Upgrade";
surname = "Hub";

console.log (name + surname);