// Crea 3 varaibles niloLenght con valor 175, tamesisLenght con valor 55 y isNiloLargest con valor false


// Si el nilo es más largo cambia el valor de isNiloLargest

var niloLenght = 175;
var tamesisLenght = 55;
var isNiloLargest = false; 

if (niloLenght > tamesisLenght) {
  isNiloLargest = true;
  }