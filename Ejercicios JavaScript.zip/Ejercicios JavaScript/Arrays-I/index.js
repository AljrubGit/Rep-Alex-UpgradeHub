// Crea una variable de tipo array llamada alimentos que contenga las siguientes cadenas de texto: "Lentejas", "Aguacate", "Tomate"


// Ahora empuja un nuevo valor "Hummus" al final de la variable alimentos.


// Empuja ahora dos valores de una sola vez en la variable. "Cebolla" y "Bacon"


// ¡Ya tenemos nuestra ensalada de lentejas! Pero viene a comer a casa un amigo vegetariano y no puede comer Bacon. Vamos a sacar el últimos elemento del array antes de terminar.

var alimentos = ["Lentejas","Aguacate","Tomate"]
alimentos.push("Hummus")
alimentos.push("Cebolla","Bacon")
alimentos.pop();

console.log(alimentos);

