// Declara dos variables llamadas 'nombre' y 'apellido' con los valores "Juan" y "Upgrader" respectivamente.


// Declara una variable llamada 'nombreCompleto' que sea igual a la suma de nombre y apellido. ¡Sepáralas con un espacio!


// Declara ahora una variable llamada 'edad' que valga 28 (número).


// Declara finalmente una variable llamada 'mensaje' que diga "Mi nombre es NOMBRE COMPLETO y tengo X años" donde NOMBRE COMPLETO será la variable nombreCompleto y X será la variable edad. 

var nombre = "Juan";
var apellido = "Upgrader"; 

var nombreCompleto = nombre + ' ' + apellido;

var edad = 28;

var mensaje = "Mi nombre es " + nombreCompleto + " y tengo " + edad + " años";