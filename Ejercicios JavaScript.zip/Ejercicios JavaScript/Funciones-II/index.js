// Vamos a crear una función llamada multiplicaDosNumeros. Esta función se encargará de multiplicar DOS números diferentes entre sí y devolverá el resultado. Debe poder recibir por tanto, dos argumentos, a los que podemos llamar numA y numB, que representarán el primer y el segundo número utilizado.


// Usando la función, crea una nueva variable primerMulti que sea igual al resultado de invocar la función con los números 4 y 5.


// Ahora crea una función llamada restaDos que reciba DOS argumentos, primerNum y segundoNum, y reste al primer número el segundo número enviado.


// Por último, crea una nueva variable resultadoFinal que sea igual al resultado de invocar la función restaDos con los números 50 y la variable primerMulti.

function multiplicaDosNumeros(numA, numB) {
return numA * numB
}

var primerMulti = multiplicaDosNumeros(4, 5);

console.log(primerMulti);

function restaDos (primerNum, segundoNum){
  return primerNum - segundoNum
  }

var resultadoFinal = restaDos(50, primerMulti)
console.log(resultadoFinal)