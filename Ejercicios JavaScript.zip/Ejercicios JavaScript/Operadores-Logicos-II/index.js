// Punto 1:
// Declara una variable llamada tengoDinero que valga true.


// Declara una variable llamada meDaMiedoVolar que valga false.


// Declara una variable edad que valga 30.


// 🚨 ¡Comprueba ahora si has conseguido el primer punto de la prueba! 🎉


// Punto 2:
// Declara una variable puedoVolar que debe pasar el test. Para ello, tendrás que hacer que esta variable sea igual a la comprobación que diga:
// 1. SI tengoDinero (comprobaremos que es true)
// 2. NO meDaMiedoVolar (negaremos esta variable que era true)
// 3. edad debe ser MAYOR O IGUAL de 18 años (en números) 


// 🚨 ¡Comprueba ahora si has conseguido el segundo punto de la prueba! 🎉

var tengoDinero = true;
var meDaMiedoVolar = false;;
var edad = 30;

var puedoVolar = tengoDinero == true;

console.log (puedoVolar);

var siQuePuedo = !meDaMiedoVolar;
var edad1 = edad === 30; 

console.log(edad1);

