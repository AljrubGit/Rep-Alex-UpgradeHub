const tengoDinero = "Ojalá";
let meDaMiedoVolar = "No"; 

var puedoIrAMexico;

puedoIrAMexico= true;
console.log(puedoIrAMexico)




